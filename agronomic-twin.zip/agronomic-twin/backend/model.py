"""
Agronomic Twin — Sujet 03: Crop Stress Detection
Core ML logic:
  - Prophet seasonal NDVI baseline (per-system stratified)
  - Z-score anomaly on 3-week sliding window
  - Isolation Forest multi-feature scoring
  - PELT change-point detection (ruptures)
  - CHIRPS / Open-Meteo weather feature integration
  - LST thermal stress bonus module
  - Auto-explanation engine
"""

import numpy as np
import pandas as pd
from prophet import Prophet
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import ruptures as rpt
from scipy import stats
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────
# CONSTANTS — tuned per EZZAYRA olive orchard system types
# ─────────────────────────────────────────────────────────

SYSTEM_NDVI_RANGES = {
    "extensif":       {"min": 0.15, "max": 0.45, "typical": 0.28},
    "intensif":       {"min": 0.30, "max": 0.65, "typical": 0.48},
    "hyper-intensif": {"min": 0.45, "max": 0.80, "typical": 0.62},
}

# Seasonal NDVI adjustment factors for Tunisia olive phenology
# Months: Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
TUNISIA_OLIVE_PHENOLOGY = {
    1:  0.85,  # dormancy
    2:  0.88,  # late dormancy
    3:  0.92,  # bud break
    4:  1.00,  # spring flush
    5:  1.05,  # peak vegetative
    6:  1.02,  # fruit set
    7:  0.97,  # fruit growth (summer stress possible)
    8:  0.93,  # fruit growth (peak heat)
    9:  0.90,  # fruit maturation
    10: 0.92,  # harvest approaching
    11: 0.88,  # post-harvest
    12: 0.85,  # early dormancy
}

STRESS_THRESHOLDS = {
    "vert":   1.0,
    "orange": 1.8,
    "rouge":  2.5,
}


# ─────────────────────────────────────────────────────────
# 1. PROPHET BASELINE — seasonal NDVI per system type
# ─────────────────────────────────────────────────────────

def compute_baseline_prophet(dates: list, ndvi: list, systeme: str = "intensif") -> np.ndarray:
    """
    Fit Prophet on historical NDVI, accounting for:
      - Olive phenology seasonality
      - System-type NDVI range normalization
      - Tunisian climate yearly cycle
    Returns expected NDVI array aligned to input dates.
    """
    df = pd.DataFrame({
        "ds": pd.to_datetime(dates),
        "y": np.array(ndvi, dtype=float)
    }).dropna()

    if len(df) < 4:
        # Fallback: phenology-adjusted mean
        baseline = []
        sys_info = SYSTEM_NDVI_RANGES.get(systeme, SYSTEM_NDVI_RANGES["intensif"])
        for d in pd.to_datetime(dates):
            factor = TUNISIA_OLIVE_PHENOLOGY.get(d.month, 1.0)
            baseline.append(sys_info["typical"] * factor)
        return np.array(baseline)

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=False,
        daily_seasonality=False,
        seasonality_mode="multiplicative",
        changepoint_prior_scale=0.05,    # conservative — olive NDVI is slow-moving
        seasonality_prior_scale=15.0,
        interval_width=0.95,
    )

    # Add Tunisian olive-specific yearly regressors
    model.add_seasonality(
        name="olive_phenology",
        period=365.25,
        fourier_order=5,
    )

    model.fit(df)

    future = pd.DataFrame({"ds": pd.to_datetime(dates)})
    forecast = model.predict(future)

    baseline = forecast["yhat"].values

    # Clamp to system-plausible range
    sys_info = SYSTEM_NDVI_RANGES.get(systeme, SYSTEM_NDVI_RANGES["intensif"])
    baseline = np.clip(baseline, sys_info["min"] * 0.8, sys_info["max"] * 1.1)

    return baseline


# ─────────────────────────────────────────────────────────
# 2. SLIDING WINDOW Z-SCORE — 3-week window anomaly
# ─────────────────────────────────────────────────────────

def compute_sliding_zscore(observed: list, expected: list, window: int = 3) -> list:
    """
    Compute normalized deviation on sliding window.
    Window = 3 observations (≈3 Sentinel-2 revisits over ~18 days).
    Returns z-score per timepoint.
    """
    obs = np.array(observed, dtype=float)
    exp = np.array(expected, dtype=float)
    residuals = obs - exp
    z_scores = []

    for i in range(len(residuals)):
        start = max(0, i - window + 1)
        window_res = residuals[start:i + 1]
        if len(window_res) < 2:
            z_scores.append(0.0)
            continue
        mu = np.mean(window_res)
        sigma = np.std(window_res) + 1e-6
        z = (residuals[i] - mu) / sigma
        z_scores.append(float(z))

    return z_scores


def get_current_zscore(z_scores: list) -> float:
    """Return the most recent z-score (current state)."""
    return z_scores[-1] if z_scores else 0.0


# ─────────────────────────────────────────────────────────
# 3. ISOLATION FOREST — multi-feature anomaly scoring
# ─────────────────────────────────────────────────────────

def compute_isolation_forest_score(
    ndvi: list,
    rainfall: list = None,
    temperature: list = None,
    lst: list = None,
) -> tuple:
    """
    Multi-feature Isolation Forest.
    Features: NDVI + NDVI gradient + rainfall deviation + temperature + LST (if available).
    Returns (anomaly_score_current, all_scores).
    """
    ndvi_arr = np.array(ndvi, dtype=float)
    n = len(ndvi_arr)

    # Build feature matrix
    features = [ndvi_arr]

    # NDVI gradient (rate of change)
    ndvi_gradient = np.gradient(ndvi_arr)
    features.append(ndvi_gradient)

    # NDVI acceleration
    ndvi_accel = np.gradient(ndvi_gradient)
    features.append(ndvi_accel)

    if rainfall is not None and len(rainfall) == n:
        rain_arr = np.array(rainfall, dtype=float)
        features.append(rain_arr)

    if temperature is not None and len(temperature) == n:
        temp_arr = np.array(temperature, dtype=float)
        features.append(temp_arr)

    if lst is not None and len(lst) == n:
        lst_arr = np.array(lst, dtype=float)
        features.append(lst_arr)

    X = np.column_stack(features)

    # Normalize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Isolation Forest
    contamination = min(0.20, max(0.05, 1.0 / n))
    model = IsolationForest(
        contamination=contamination,
        n_estimators=200,
        max_samples="auto",
        random_state=42
    )
    model.fit(X_scaled)

    raw_scores = -model.decision_function(X_scaled)
    # Normalize to [0, 3] range
    if raw_scores.max() > raw_scores.min():
        iso_scores = (raw_scores - raw_scores.min()) / (raw_scores.max() - raw_scores.min()) * 3.0
    else:
        iso_scores = raw_scores * 0

    return float(iso_scores[-1]), iso_scores.tolist()


# ─────────────────────────────────────────────────────────
# 4. CHANGE POINT DETECTION — PELT algorithm
# ─────────────────────────────────────────────────────────

def detect_change_points(ndvi: list, dates: list) -> dict:
    """
    PELT (Pruned Exact Linear Time) change point detection.
    Identifies when stress onset began and its severity.
    """
    ndvi_arr = np.array(ndvi, dtype=float)

    if len(ndvi_arr) < 6:
        return {"stress_start_date": None, "n_breakpoints": 0, "severity": 0.0}

    try:
        algo = rpt.Pelt(model="rbf", min_size=2, jump=1).fit(ndvi_arr)
        breakpoints = algo.predict(pen=3)
        # ruptures always adds end index
        actual_bps = breakpoints[:-1]

        if not actual_bps:
            return {"stress_start_date": None, "n_breakpoints": 0, "severity": 0.0}

        # Last breakpoint = most recent stress onset
        last_bp_idx = actual_bps[-1]
        stress_start = pd.to_datetime(dates[last_bp_idx]).strftime("%Y-%m-%d")

        # Severity: mean NDVI drop after vs before breakpoint
        before_mean = np.mean(ndvi_arr[:last_bp_idx]) if last_bp_idx > 0 else ndvi_arr[0]
        after_mean = np.mean(ndvi_arr[last_bp_idx:])
        severity = float(max(0, before_mean - after_mean))

        return {
            "stress_start_date": stress_start,
            "n_breakpoints": len(actual_bps),
            "breakpoint_indices": actual_bps,
            "ndvi_drop": round(severity, 4),
        }

    except Exception:
        return {"stress_start_date": None, "n_breakpoints": 0, "severity": 0.0}


# ─────────────────────────────────────────────────────────
# 5. LST THERMAL STRESS MODULE (bonus)
# ─────────────────────────────────────────────────────────

def analyze_lst_thermal_stress(lst_values: list, dates: list) -> dict:
    """
    Analyze Land Surface Temperature for pre-NDVI thermal stress detection.
    Olive critical thresholds for Tunisia:
      - > 38°C LST → heat stress risk
      - Sustained > 35°C for 3+ consecutive days → confirmed stress
    """
    if not lst_values:
        return {"thermal_stress": False, "max_lst": None, "stress_days": 0}

    lst_arr = np.array(lst_values, dtype=float)
    heat_threshold = 38.0  # °C, olive heat stress onset
    sustained_threshold = 35.0

    max_lst = float(np.nanmax(lst_arr))
    stress_days = int(np.sum(lst_arr > heat_threshold))

    # Detect sustained heat events (3+ consecutive days > 35°C)
    sustained_event = False
    consecutive = 0
    for v in lst_arr:
        if v > sustained_threshold:
            consecutive += 1
            if consecutive >= 3:
                sustained_event = True
                break
        else:
            consecutive = 0

    return {
        "thermal_stress": sustained_event or stress_days > 2,
        "max_lst": round(max_lst, 1),
        "stress_days_above_38C": stress_days,
        "sustained_heat_event": sustained_event,
    }


# ─────────────────────────────────────────────────────────
# 6. DYNAMIC THRESHOLD CLASSIFICATION
# ─────────────────────────────────────────────────────────

def classify_anomaly(
    z_score: float,
    iso_score: float,
    ndvi_drop: float = 0.0,
    thermal_stress: bool = False,
    systeme: str = "intensif",
) -> tuple:
    """
    Ensemble scoring with dynamic thresholds.
    Combines Z-score + Isolation Forest + NDVI drop + LST thermal bonus.
    Returns (status, composite_score, confidence).
    """
    # Composite score (weighted ensemble)
    composite = (
        abs(z_score) * 0.45          # primary: statistical deviation
        + iso_score * 0.35            # secondary: multi-feature isolation
        + ndvi_drop * 3.0 * 0.20     # tertiary: absolute NDVI drop
    )

    # LST thermal bonus: escalate alert level
    if thermal_stress:
        composite += 0.5

    # System-adjusted thresholds
    # Extensif has naturally higher variability → higher thresholds
    multiplier = {"extensif": 1.2, "intensif": 1.0, "hyper-intensif": 0.85}.get(systeme, 1.0)
    thresh_orange = STRESS_THRESHOLDS["orange"] * multiplier
    thresh_rouge = STRESS_THRESHOLDS["rouge"] * multiplier

    if composite >= thresh_rouge:
        status = "rouge"
        confidence = min(0.99, 0.70 + (composite - thresh_rouge) * 0.1)
    elif composite >= thresh_orange:
        status = "orange"
        confidence = min(0.85, 0.55 + (composite - thresh_orange) * 0.1)
    else:
        status = "vert"
        confidence = min(0.95, 0.80 + (thresh_orange - composite) * 0.1)

    return status, round(composite, 3), round(confidence, 3)


# ─────────────────────────────────────────────────────────
# 7. EXPLANATION ENGINE
# ─────────────────────────────────────────────────────────

def generate_explanation(
    z_score: float,
    iso_score: float,
    ndvi_drop: float,
    status: str,
    systeme: str,
    stress_date: str,
    thermal_stress: bool,
    rainfall_deficit: float = None,
) -> dict:
    """
    Auto-generate human-readable explanation and recommendation.
    Tailored to olive agronomic context in Tunisia.
    """
    reasons = []
    recommendations = []

    # Z-score interpretation
    if z_score < -2.5:
        reasons.append(f"Chute NDVI sévère ({abs(z_score):.1f}σ sous la normale saisonnière)")
        recommendations.append("Inspection terrain urgente dans les 24-48h")
    elif z_score < -1.5:
        reasons.append(f"Déclin NDVI modéré ({abs(z_score):.1f}σ sous l'attendu)")
        recommendations.append("Vérification irrigation conseillée sous 72h")
    elif z_score > 2.0:
        reasons.append("NDVI anormalement élevé — possible sur-irrigation ou erreur capteur")
        recommendations.append("Vérifier cohérence données satellite")

    # Rainfall deficit
    if rainfall_deficit is not None and rainfall_deficit < -20:
        reasons.append(f"Déficit pluviométrique significatif ({abs(rainfall_deficit):.0f}mm sous la normale)")
        recommendations.append("Activer irrigation d'appoint si non planifiée")

    # Thermal stress
    if thermal_stress:
        reasons.append("Stress thermique détecté (LST > 38°C) — visible avant chute NDVI")
        recommendations.append("Surveiller humidité foliaire et stomatal conductance")

    # NDVI drop
    if ndvi_drop > 0.08:
        reasons.append(f"Perte végétative absolue de {ndvi_drop:.2f} points NDVI depuis le changement de régime")

    # System-specific context
    sys_context = {
        "extensif": "Le système extensif sec tolère plus de variabilité naturelle",
        "intensif": "Le système intensif irrigué devrait maintenir un NDVI stable",
        "hyper-intensif": "Le haies hyper-intensif est sensible aux variations — réponse rapide requise",
    }
    context = sys_context.get(systeme, "")

    # Status-based final message
    if status == "rouge":
        main_msg = "⚠️ ALERTE ROUGE : Stress probable confirmé par plusieurs indicateurs"
        if not recommendations:
            recommendations.append("Inspection terrain immédiate — pertes actées si délai > 48h")
    elif status == "orange":
        main_msg = "🟠 VIGILANCE : Anomalie détectée, comportement à surveiller"
        if not recommendations:
            recommendations.append("Réévaluation sous 7 jours avec nouvelle acquisition satellite")
    else:
        main_msg = "✅ NORMAL : Végétation dans les normes saisonnières attendues"
        recommendations.append("Continuer surveillance routine")

    if stress_date:
        reasons.append(f"Début de déviation détecté autour du {stress_date}")

    return {
        "message_principal": main_msg,
        "raisons": reasons if reasons else ["Comportement NDVI conforme au baseline saisonnier"],
        "recommandations": recommendations,
        "contexte_systeme": context,
    }


# ─────────────────────────────────────────────────────────
# 8. FULL PIPELINE
# ─────────────────────────────────────────────────────────

def run_full_detection(
    orchard_id: str,
    dates: list,
    ndvi: list,
    systeme: str = "intensif",
    rainfall: list = None,
    temperature: list = None,
    lst: list = None,
) -> dict:
    """
    Master orchestrator — runs the full anomaly detection pipeline.
    """
    # 1. Prophet baseline
    baseline = compute_baseline_prophet(dates, ndvi, systeme)

    # 2. Sliding Z-score
    z_scores = compute_sliding_zscore(ndvi, baseline, window=3)
    current_z = get_current_zscore(z_scores)

    # 3. Isolation Forest
    iso_current, iso_all = compute_isolation_forest_score(ndvi, rainfall, temperature, lst)

    # 4. Change point detection
    cp_info = detect_change_points(ndvi, dates)
    ndvi_drop = cp_info.get("ndvi_drop", 0.0)

    # 5. LST thermal stress
    thermal_info = analyze_lst_thermal_stress(lst or [], dates)
    thermal_stress = thermal_info["thermal_stress"]

    # 6. Classification
    status, composite_score, confidence = classify_anomaly(
        current_z, iso_current, ndvi_drop, thermal_stress, systeme
    )

    # 7. Rainfall deficit calculation
    rainfall_deficit = None
    if rainfall and len(rainfall) >= 4:
        recent_rain = sum(rainfall[-4:])
        hist_rain = sum(rainfall[:-4]) / max(1, len(rainfall) - 4) * 4
        rainfall_deficit = recent_rain - hist_rain

    # 8. Explanation
    explanation = generate_explanation(
        current_z, iso_current, ndvi_drop, status, systeme,
        cp_info.get("stress_start_date"), thermal_stress, rainfall_deficit
    )

    return {
        "id": orchard_id,
        "statut": status,
        "anomaly_score": composite_score,
        "confidence": confidence,
        "z_score_actuel": round(current_z, 3),
        "iso_score": round(iso_current, 3),
        "ndvi_observe": [round(v, 4) for v in ndvi],
        "ndvi_attendu": [round(float(v), 4) for v in baseline],
        "z_scores_historique": [round(z, 3) for z in z_scores],
        "iso_scores_historique": [round(s, 3) for s in iso_all],
        "dates": dates,
        "changement_regime": {
            "date_debut_stress": cp_info.get("stress_start_date"),
            "nb_ruptures": cp_info.get("n_breakpoints", 0),
            "chute_ndvi": round(ndvi_drop, 4),
        },
        "stress_thermique": thermal_info,
        "explication": explanation,
        "metadata": {
            "systeme": systeme,
            "n_observations": len(ndvi),
            "periode_couverte": f"{dates[0]} → {dates[-1]}" if dates else "N/A",
        }
    }
