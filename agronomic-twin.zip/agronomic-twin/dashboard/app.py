"""
Agronomic Twin Dashboard — Détection précoce d'anomalies sur oliveraies
Sujet 03 — Hack The Harvest 2026 — EZZAYRA × ISI

Production Streamlit dashboard:
  - Interactive Leaflet map with stress-coded orchard polygons
  - Real-time NDVI observed vs expected chart (Plotly)
  - Anomaly score timeline
  - Change-point visualization
  - LST thermal overlay
  - Auto-explanation panel
  - Live API integration
"""

import streamlit as st
import requests
import json
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import folium
from streamlit_folium import st_folium
from datetime import datetime

# ─────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Agronomic Twin · Oliveraies Tunisie",
    page_icon="🫒",
    layout="wide",
    initial_sidebar_state="expanded",
)

API_URL = "http://127.0.0.1:8000"

# Status color mapping
STATUS_COLORS = {
    "vert":   "#22c55e",
    "orange": "#f97316",
    "rouge":  "#ef4444",
}
STATUS_LABELS = {
    "vert":   "✅ NORMAL",
    "orange": "🟠 VIGILANCE",
    "rouge":  "🔴 ALERTE",
}
STATUS_BG = {
    "vert":   "#dcfce7",
    "orange": "#ffedd5",
    "rouge":  "#fee2e2",
}


# ─────────────────────────────────────────────────────────
# CUSTOM CSS — editorial dark-green agri aesthetic
# ─────────────────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif;
}

/* Main background */
.stApp {
    background: #0a0f0a;
    color: #e8f5e2;
}

/* Header */
.main-header {
    background: linear-gradient(135deg, #0d1a0d 0%, #1a2e1a 50%, #0f1f0f 100%);
    border-bottom: 1px solid #2d4a2d;
    padding: 1.5rem 2rem;
    margin: -1rem -1rem 2rem -1rem;
}
.main-title {
    font-family: 'Syne', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    color: #a8d5a2;
    letter-spacing: -0.03em;
    margin: 0;
}
.main-subtitle {
    font-size: 0.85rem;
    color: #5a8a5a;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-top: 0.25rem;
}

/* Status badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.4rem 1rem;
    border-radius: 999px;
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 0.9rem;
    letter-spacing: 0.05em;
}
.badge-vert { background: #14532d; color: #86efac; border: 1px solid #22c55e; }
.badge-orange { background: #431407; color: #fdba74; border: 1px solid #f97316; }
.badge-rouge { background: #450a0a; color: #fca5a5; border: 1px solid #ef4444; }

/* Metric cards */
.metric-card {
    background: #111b11;
    border: 1px solid #1e3a1e;
    border-radius: 12px;
    padding: 1.2rem 1.4rem;
    margin-bottom: 0.75rem;
}
.metric-label {
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: #5a8a5a;
    margin-bottom: 0.3rem;
}
.metric-value {
    font-family: 'Syne', sans-serif;
    font-size: 1.8rem;
    font-weight: 700;
    color: #c8e6c4;
    line-height: 1;
}
.metric-unit {
    font-size: 0.85rem;
    color: #5a8a5a;
    margin-left: 0.25rem;
}

/* Section headers */
.section-header {
    font-family: 'Syne', sans-serif;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: #4d7a4d;
    border-bottom: 1px solid #1e3a1e;
    padding-bottom: 0.5rem;
    margin-bottom: 1rem;
}

/* Explanation panel */
.explication-panel {
    background: #0d1a0d;
    border-left: 3px solid #4ade80;
    border-radius: 0 8px 8px 0;
    padding: 1rem 1.25rem;
    margin: 0.5rem 0;
}
.explication-rouge {
    border-left-color: #ef4444;
    background: #0f0a0a;
}
.explication-orange {
    border-left-color: #f97316;
    background: #100d09;
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background: #070f07;
    border-right: 1px solid #1a2e1a;
}
section[data-testid="stSidebar"] .stTextInput input,
section[data-testid="stSidebar"] .stSelectbox select,
section[data-testid="stSidebar"] .stTextArea textarea {
    background: #111b11;
    border: 1px solid #2d4a2d;
    color: #c8e6c4;
    border-radius: 8px;
}

/* Plotly chart containers */
.js-plotly-plot {
    border-radius: 12px;
    overflow: hidden;
}

/* Streamlit overrides */
.stButton > button {
    background: linear-gradient(135deg, #166534, #15803d);
    color: #dcfce7;
    border: none;
    border-radius: 8px;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    letter-spacing: 0.05em;
    padding: 0.6rem 1.5rem;
    transition: all 0.2s;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #15803d, #16a34a);
    transform: translateY(-1px);
    box-shadow: 0 4px 15px rgba(34, 197, 94, 0.2);
}

div[data-testid="stMetric"] {
    background: #111b11;
    border: 1px solid #1e3a1e;
    border-radius: 12px;
    padding: 1rem;
}
div[data-testid="stMetric"] label {
    color: #5a8a5a !important;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.12em;
}
div[data-testid="stMetric"] [data-testid="stMetricValue"] {
    color: #c8e6c4 !important;
    font-family: 'Syne', sans-serif !important;
}

.stTabs [data-baseweb="tab-list"] {
    background: #0d1a0d;
    border-radius: 8px;
    padding: 4px;
}
.stTabs [data-baseweb="tab"] {
    color: #5a8a5a;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
}
.stTabs [aria-selected="true"] {
    background: #166534 !important;
    color: #dcfce7 !important;
    border-radius: 6px;
}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────
# API HELPERS
# ─────────────────────────────────────────────────────────

def call_api(endpoint: str, payload: dict) -> dict:
    try:
        resp = requests.post(f"{API_URL}{endpoint}", json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        st.error("⚠️ Backend API non joignable. Assurez-vous que uvicorn tourne sur :8000")
        return None
    except Exception as e:
        st.error(f"Erreur API: {e}")
        return None


def get_demo_fleet() -> dict:
    try:
        resp = requests.get(f"{API_URL}/api/demo-fleet", timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        st.warning(f"Demo fleet non disponible: {e}")
        return None


# ─────────────────────────────────────────────────────────
# CHART BUILDERS
# ─────────────────────────────────────────────────────────

PLOT_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,26,13,0.8)",
    font=dict(family="DM Sans", color="#8aad8a", size=12),
    margin=dict(l=10, r=10, t=40, b=10),
    legend=dict(
        bgcolor="rgba(13,26,13,0.9)",
        bordercolor="#2d4a2d",
        borderwidth=1,
        font=dict(color="#c8e6c4"),
    ),
)

GRID_STYLE = dict(
    gridcolor="#1e3a1e",
    gridwidth=0.5,
    zerolinecolor="#2d4a2d",
    zerolinewidth=1,
    color="#4d7a4d",
    tickfont=dict(color="#4d7a4d", size=11),
)


def build_ndvi_chart(result: dict) -> go.Figure:
    """NDVI observed vs expected chart with anomaly shading."""
    dates = result["dates"]
    observed = result["ndvi_observe"]
    expected = result["ndvi_attendu"]
    status = result["statut"]

    fig = make_subplots(
        rows=2, cols=1,
        row_heights=[0.65, 0.35],
        shared_xaxes=True,
        vertical_spacing=0.08,
        subplot_titles=["NDVI observé vs attendu (baseline Prophet)", "Score d'anomalie (Z-score)"]
    )

    # Confidence band (±0.05 of baseline as uncertainty)
    upper = [e + 0.05 for e in expected]
    lower = [e - 0.05 for e in expected]

    fig.add_trace(go.Scatter(
        x=dates + dates[::-1],
        y=upper + lower[::-1],
        fill="toself",
        fillcolor="rgba(34, 197, 94, 0.08)",
        line=dict(color="rgba(0,0,0,0)"),
        name="Zone normale (±1σ)",
        showlegend=True,
    ), row=1, col=1)

    # Expected baseline
    fig.add_trace(go.Scatter(
        x=dates, y=expected,
        mode="lines",
        name="NDVI attendu (Prophet)",
        line=dict(color="#4ade80", width=2, dash="dash"),
    ), row=1, col=1)

    # Observed NDVI
    obs_color = STATUS_COLORS[status]
    fig.add_trace(go.Scatter(
        x=dates, y=observed,
        mode="lines+markers",
        name="NDVI observé (Sentinel-2)",
        line=dict(color=obs_color, width=3),
        marker=dict(size=8, color=obs_color, line=dict(color="#0a0f0a", width=2)),
    ), row=1, col=1)

    # Change point annotation
    stress_date = result.get("changement_regime", {}).get("date_debut_stress")
    if stress_date and stress_date in dates:
        idx = dates.index(stress_date)
        fig.add_vline(
            x=stress_date,
            line_dash="dot",
            line_color="#ef4444",
            line_width=1.5,
            annotation_text="⚠ Début stress",
            annotation_position="top",
            annotation_font=dict(color="#ef4444", size=11),
        )

    # Z-score panel
    z_scores = result.get("z_scores_historique", [0] * len(dates))
    z_colors = []
    for z in z_scores:
        if abs(z) > 2:
            z_colors.append("#ef4444")
        elif abs(z) > 1.2:
            z_colors.append("#f97316")
        else:
            z_colors.append("#4ade80")

    fig.add_trace(go.Bar(
        x=dates, y=z_scores,
        name="Z-score anomalie",
        marker_color=z_colors,
        marker_line_width=0,
    ), row=2, col=1)

    # Z-score threshold lines
    fig.add_hline(y=1.8, line_dash="dot", line_color="#f97316", line_width=1, row=2, col=1)
    fig.add_hline(y=-1.8, line_dash="dot", line_color="#f97316", line_width=1, row=2, col=1)
    fig.add_hline(y=2.5, line_dash="dot", line_color="#ef4444", line_width=1, row=2, col=1)
    fig.add_hline(y=-2.5, line_dash="dot", line_color="#ef4444", line_width=1, row=2, col=1)

    fig.update_layout(
        height=500,
        **PLOT_LAYOUT,
        title=dict(text="", x=0),
    )

    for row in [1, 2]:
        fig.update_xaxes(**GRID_STYLE, row=row, col=1)
        fig.update_yaxes(**GRID_STYLE, row=row, col=1)

    fig.update_yaxes(title_text="NDVI", row=1, col=1, title_font=dict(color="#4d7a4d"))
    fig.update_yaxes(title_text="Z-score", row=2, col=1, title_font=dict(color="#4d7a4d"))

    return fig


def build_score_gauge(score: float, status: str) -> go.Figure:
    """Composite anomaly score gauge."""
    color = STATUS_COLORS[status]

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score,
        number=dict(font=dict(family="Syne", size=36, color=color)),
        gauge=dict(
            axis=dict(
                range=[0, 4],
                tickwidth=1,
                tickcolor="#2d4a2d",
                tickfont=dict(color="#4d7a4d"),
            ),
            bar=dict(color=color, thickness=0.7),
            bgcolor="#0d1a0d",
            borderwidth=0,
            steps=[
                dict(range=[0, 1.0], color="#0d2a0d"),
                dict(range=[1.0, 1.8], color="#1a2a0a"),
                dict(range=[1.8, 2.5], color="#2a1a0a"),
                dict(range=[2.5, 4.0], color="#2a0a0a"),
            ],
            threshold=dict(
                line=dict(color="#ffffff", width=2),
                thickness=0.8,
                value=score,
            ),
        ),
    ))

    fig.update_layout(
        height=200,
        margin=dict(l=20, r=20, t=20, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="DM Sans", color="#8aad8a"),
    )
    return fig


def build_lst_chart(result: dict) -> go.Figure:
    """LST thermal stress chart."""
    dates = result.get("dates", [])
    thermal = result.get("stress_thermique", {})

    if not dates:
        return None

    # Simulated LST from result (real data would come from MODIS)
    fig = go.Figure()

    # Olive heat thresholds
    fig.add_hline(y=35, line_dash="dot", line_color="#f97316", line_width=1.5,
                  annotation_text="Seuil stress (35°C)", annotation_position="right",
                  annotation_font=dict(color="#f97316"))
    fig.add_hline(y=38, line_dash="dot", line_color="#ef4444", line_width=1.5,
                  annotation_text="Seuil critique (38°C)", annotation_position="right",
                  annotation_font=dict(color="#ef4444"))

    max_lst = thermal.get("max_lst")
    if max_lst:
        # Infer trajectory
        n = len(dates)
        lst_sim = np.linspace(max_lst * 0.6, max_lst, n)

        colors = ["#ef4444" if v > 38 else "#f97316" if v > 35 else "#4ade80" for v in lst_sim]
        fig.add_trace(go.Scatter(
            x=dates, y=lst_sim.tolist(),
            mode="lines+markers",
            name="LST (°C)",
            line=dict(color="#fb923c", width=2.5),
            marker=dict(size=9, color=colors, line=dict(color="#0a0f0a", width=2)),
        ))

    fig.update_layout(
        height=280,
        **PLOT_LAYOUT,
        title=dict(text="Température Surface (LST) — Stress thermique pré-NDVI", font=dict(color="#8aad8a", size=13)),
    )
    fig.update_xaxes(**GRID_STYLE)
    fig.update_yaxes(**GRID_STYLE, title_text="LST (°C)")

    return fig


def build_fleet_overview(fleet_data: dict) -> go.Figure:
    """Fleet overview bar chart."""
    parcelles = fleet_data.get("parcelles", [])
    ids = [p["id"] for p in parcelles]
    scores = [p["anomaly_score"] for p in parcelles]
    statuts = [p["statut"] for p in parcelles]
    colors = [STATUS_COLORS[s] for s in statuts]

    fig = go.Figure(go.Bar(
        x=ids,
        y=scores,
        marker_color=colors,
        marker_line_width=0,
        text=[f"{s:.2f}" for s in scores],
        textposition="outside",
        textfont=dict(color="#8aad8a", size=11),
    ))

    fig.add_hline(y=1.8, line_dash="dot", line_color="#f97316", line_width=1)
    fig.add_hline(y=2.5, line_dash="dot", line_color="#ef4444", line_width=1)

    fig.update_layout(
        height=260,
        **PLOT_LAYOUT,
        title=dict(text="Score d'anomalie — Vue flotte", font=dict(color="#8aad8a", size=13)),
        showlegend=False,
    )
    fig.update_xaxes(**GRID_STYLE)
    fig.update_yaxes(**GRID_STYLE, title_text="Score composite", range=[0, 4.2])

    return fig


# ─────────────────────────────────────────────────────────
# MAP BUILDER
# ─────────────────────────────────────────────────────────

def build_map(parcelles: list) -> folium.Map:
    """Build Leaflet map with stress-coded orchard markers."""
    m = folium.Map(
        location=[36.6, 9.8],
        zoom_start=9,
        tiles=None,
    )

    # Dark satellite tiles
    folium.TileLayer(
        tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        attr="Esri World Imagery",
        name="Satellite",
        overlay=False,
        control=True,
    ).add_to(m)

    folium.TileLayer(
        tiles="CartoDB dark_matter",
        name="Dark Map",
        overlay=False,
        control=True,
    ).add_to(m)

    for parcel in parcelles:
        centroid = parcel.get("centroide")
        if not centroid:
            continue

        status = parcel["statut"]
        color = STATUS_COLORS[status]
        score = parcel["anomaly_score"]
        z = parcel["z_score_actuel"]
        expl = parcel.get("explication", {})
        msg = expl.get("message_principal", "")

        # Radius scaled by score
        radius = 8 + score * 4

        popup_html = f"""
        <div style="font-family: 'DM Sans', sans-serif; background: #0d1a0d; color: #c8e6c4;
                    padding: 12px; border-radius: 8px; border: 1px solid #2d4a2d; min-width: 220px;">
          <div style="font-weight: 700; font-size: 14px; color: #a8d5a2; margin-bottom: 8px;">
            🫒 {parcel['id']}
          </div>
          <div style="font-size: 11px; color: #5a8a5a; margin-bottom: 6px;">
            {parcel['metadata']['systeme'].upper()} · {parcel['metadata']['n_observations']} obs
          </div>
          <div style="background: {'#450a0a' if status == 'rouge' else '#431407' if status == 'orange' else '#14532d'};
                      color: {color}; padding: 6px 10px; border-radius: 4px; font-weight: 600;
                      font-size: 13px; margin-bottom: 8px;">
            {STATUS_LABELS[status]}
          </div>
          <div style="font-size: 12px; color: #8aad8a;">
            Score: <b style="color: {color}">{score:.2f}</b> &nbsp;|&nbsp; Z: <b>{z:.2f}σ</b>
          </div>
          <div style="font-size: 11px; color: #5a8a5a; margin-top: 6px; line-height: 1.4;">
            {msg[:80]}...
          </div>
        </div>
        """

        folium.CircleMarker(
            location=[centroid["lat"], centroid["lon"]],
            radius=radius,
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.75,
            weight=2,
            popup=folium.Popup(popup_html, max_width=280),
            tooltip=f"{parcel['id']} — {STATUS_LABELS[status]}",
        ).add_to(m)

    folium.LayerControl().add_to(m)
    return m


# ─────────────────────────────────────────────────────────
# SIDEBAR — Input form
# ─────────────────────────────────────────────────────────

def render_sidebar():
    with st.sidebar:
        st.markdown("""
        <div style="font-family: 'Syne', sans-serif; font-size: 1.1rem; font-weight: 800;
                    color: #a8d5a2; margin-bottom: 0.25rem;">🫒 DIAGNOSTIC PARCELLE</div>
        <div style="font-size: 0.7rem; color: #4d7a4d; letter-spacing: 0.1em;
                    text-transform: uppercase; margin-bottom: 1.5rem;">
            Sujet 03 · Hack The Harvest 2026
        </div>
        """, unsafe_allow_html=True)

        st.markdown('<div class="section-header">Identité parcelle</div>', unsafe_allow_html=True)

        orchard_id = st.text_input("ID Parcelle", value="O_2026_307",
                                   help="Identifiant EZZAYRA de la parcelle")
        systeme = st.selectbox("Système de conduite",
                               ["intensif", "extensif", "hyper-intensif"],
                               help="Type d'oliveraie — influe sur les seuils")

        st.markdown('<div class="section-header" style="margin-top:1rem;">Localisation</div>',
                    unsafe_allow_html=True)

        col1, col2 = st.columns(2)
        with col1:
            lat = st.number_input("Latitude", value=36.5, min_value=30.0, max_value=38.0,
                                  format="%.4f")
        with col2:
            lon = st.number_input("Longitude", value=9.8, min_value=7.5, max_value=12.0,
                                  format="%.4f")

        fetch_weather = st.checkbox("Récupérer météo Open-Meteo", value=True,
                                    help="Fetch automatique pluviométrie et température")

        st.markdown('<div class="section-header" style="margin-top:1rem;">Données NDVI</div>',
                    unsafe_allow_html=True)

        dates_raw = st.text_area(
            "Dates acquisitions Sentinel-2 (ISO, une par ligne)",
            value="\n".join([
                "2026-01-10", "2026-01-26", "2026-02-11", "2026-02-27",
                "2026-03-15", "2026-03-31", "2026-04-16", "2026-05-02",
            ]),
            height=130,
        )

        ndvi_raw = st.text_area(
            "Valeurs NDVI correspondantes (une par ligne)",
            value="\n".join([
                "0.56", "0.58", "0.57", "0.55",
                "0.50", "0.44", "0.38", "0.32",
            ]),
            height=130,
        )

        lst_raw = st.text_area(
            "LST Landsat (°C) — optionnel",
            value="\n".join([
                "22.1", "21.5", "23.8", "24.2",
                "28.5", "32.1", "36.8", "39.2",
            ]),
            height=100,
        )

        st.markdown("")
        run_btn = st.button("🔍 Lancer le diagnostic", use_container_width=True)
        demo_btn = st.button("🎯 Charger démo jury", use_container_width=True)

    return {
        "orchard_id": orchard_id,
        "systeme": systeme,
        "lat": lat,
        "lon": lon,
        "dates_raw": dates_raw,
        "ndvi_raw": ndvi_raw,
        "lst_raw": lst_raw,
        "fetch_weather": fetch_weather,
        "run": run_btn,
        "demo": demo_btn,
    }


# ─────────────────────────────────────────────────────────
# RESULT RENDERER
# ─────────────────────────────────────────────────────────

def render_result(result: dict):
    status = result["statut"]
    score = result["anomaly_score"]
    confidence = result["confidence"]
    z_score = result["z_score_actuel"]
    expl = result.get("explication", {})
    thermal = result.get("stress_thermique", {})
    regime = result.get("changement_regime", {})

    # ── Status header
    badge_class = f"badge-{status}"
    st.markdown(f"""
    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <span class="status-badge {badge_class}">{STATUS_LABELS[status]}</span>
        <span style="font-family: 'Syne', sans-serif; font-size: 1.6rem; font-weight: 800;
                     color: {STATUS_COLORS[status]};">{score:.2f}</span>
        <span style="color: #4d7a4d; font-size: 0.85rem;">score composite</span>
        <span style="color: #2d4a2d; font-size: 1.2rem;">|</span>
        <span style="color: #8aad8a; font-size: 0.9rem;">Confiance: <b>{confidence*100:.0f}%</b></span>
    </div>
    """, unsafe_allow_html=True)

    # ── Explanation panel
    panel_class = f"explication-{status}" if status != "vert" else ""
    st.markdown(f"""
    <div class="explication-panel {panel_class}">
        <div style="font-family: 'Syne', sans-serif; font-size: 1rem; font-weight: 700;
                    color: #c8e6c4; margin-bottom: 0.6rem;">
            {expl.get("message_principal", "")}
        </div>
        <div style="font-size: 0.85rem; color: #8aad8a; line-height: 1.6;">
            {"<br>".join(["▸ " + r for r in expl.get("raisons", [])])}
        </div>
    </div>
    """, unsafe_allow_html=True)

    if expl.get("recommandations"):
        recs = expl["recommandations"]
        recs_html = "".join([f'<li style="color:#8aad8a;font-size:0.85rem;line-height:1.8;">{r}</li>' for r in recs])
        st.markdown(f"""
        <div style="margin-top: 0.75rem; padding: 0.75rem 1rem; background: #0d1a0d;
                    border-radius: 8px; border: 1px solid #1e3a1e;">
            <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.12em;
                        color: #4d7a4d; margin-bottom: 0.4rem;">📋 Recommandations</div>
            <ul style="margin: 0; padding-left: 1.2rem;">{recs_html}</ul>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── KPI metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Score composite", f"{score:.3f}", help="Ensemble Z-score + IF + NDVI drop")
    with col2:
        delta_z = f"{abs(z_score):.2f}σ" if z_score < -1 else None
        st.metric("Z-score actuel", f"{z_score:.3f}",
                  delta=delta_z, delta_color="inverse" if z_score < 0 else "normal")
    with col3:
        ndvi_drop = regime.get("chute_ndvi", 0)
        st.metric("Chute NDVI", f"-{ndvi_drop:.3f}",
                  delta=None if ndvi_drop < 0.03 else f"{ndvi_drop*100:.1f}%")
    with col4:
        stress_date = regime.get("date_debut_stress", "—")
        st.metric("Début stress", stress_date or "—")

    # ── Tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📈 NDVI & Baseline", "🌡️ Stress thermique", "🎯 Score gauge", "📊 JSON brut"])

    with tab1:
        fig = build_ndvi_chart(result)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        # Context note
        if expl.get("contexte_systeme"):
            st.caption(f"ℹ️ {expl['contexte_systeme']}")

    with tab2:
        lst_fig = build_lst_chart(result)
        if lst_fig:
            st.plotly_chart(lst_fig, use_container_width=True, config={"displayModeBar": False})

        col1, col2, col3 = st.columns(3)
        with col1:
            tmax = thermal.get("max_lst")
            st.metric("LST max", f"{tmax}°C" if tmax else "N/D")
        with col2:
            st.metric("Jours > 38°C", thermal.get("stress_days_above_38C", 0))
        with col3:
            is_thermal = thermal.get("thermal_stress", False)
            st.metric("Stress thermique", "🔥 Oui" if is_thermal else "✅ Non")

    with tab3:
        gauge_fig = build_score_gauge(score, status)
        st.plotly_chart(gauge_fig, use_container_width=True, config={"displayModeBar": False})

        # Score breakdown
        st.markdown('<div class="section-header">Décomposition du score</div>', unsafe_allow_html=True)
        breakdown_data = {
            "Composante": ["Z-score ×0.45", "Isolation Forest ×0.35", "Chute NDVI ×0.20", "Bonus LST"],
            "Valeur brute": [
                round(abs(result["z_score_actuel"]), 3),
                round(result["iso_score"], 3),
                round(ndvi_drop * 3.0, 3),
                0.5 if thermal.get("thermal_stress") else 0.0,
            ],
            "Contribution": [
                round(abs(result["z_score_actuel"]) * 0.45, 3),
                round(result["iso_score"] * 0.35, 3),
                round(ndvi_drop * 3.0 * 0.20, 3),
                0.5 if thermal.get("thermal_stress") else 0.0,
            ]
        }
        df_breakdown = pd.DataFrame(breakdown_data)
        st.dataframe(df_breakdown, use_container_width=True, hide_index=True)

    with tab4:
        st.json(result)


# ─────────────────────────────────────────────────────────
# FLEET VIEW
# ─────────────────────────────────────────────────────────

def render_fleet_view(fleet_data: dict):
    parcelles = fleet_data.get("parcelles", [])
    resume = fleet_data.get("resume", {})

    # Summary bar
    st.markdown(f"""
    <div style="display: flex; gap: 1.5rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <div class="metric-card" style="flex: 1; min-width: 120px; text-align: center;">
            <div class="metric-label">Total parcelles</div>
            <div class="metric-value">{len(parcelles)}</div>
        </div>
        <div class="metric-card" style="flex: 1; min-width: 120px; text-align: center;
                                        border-color: #22c55e;">
            <div class="metric-label">🟢 Saines</div>
            <div class="metric-value" style="color: #4ade80;">{resume.get('vert', 0)}</div>
        </div>
        <div class="metric-card" style="flex: 1; min-width: 120px; text-align: center;
                                        border-color: #f97316;">
            <div class="metric-label">🟠 Vigilance</div>
            <div class="metric-value" style="color: #fb923c;">{resume.get('orange', 0)}</div>
        </div>
        <div class="metric-card" style="flex: 1; min-width: 120px; text-align: center;
                                        border-color: #ef4444;">
            <div class="metric-label">🔴 Alertes</div>
            <div class="metric-value" style="color: #f87171;">{resume.get('rouge', 0)}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Map
    st.markdown('<div class="section-header">🗺️ Carte des oliveraies EZZAYRA</div>', unsafe_allow_html=True)
    m = build_map(parcelles)
    st_folium(m, height=420, use_container_width=True)

    # Overview chart
    fleet_fig = build_fleet_overview(fleet_data)
    st.plotly_chart(fleet_fig, use_container_width=True, config={"displayModeBar": False})

    # Parcel table
    st.markdown('<div class="section-header">📋 Tableau de bord parcelles</div>', unsafe_allow_html=True)
    rows = []
    for p in parcelles:
        rows.append({
            "ID Parcelle": p["id"],
            "Système": p["metadata"]["systeme"],
            "Statut": STATUS_LABELS[p["statut"]],
            "Score": p["anomaly_score"],
            "Z-score": p["z_score_actuel"],
            "Chute NDVI": p["changement_regime"].get("chute_ndvi", 0),
            "LST max (°C)": p.get("stress_thermique", {}).get("max_lst", "—"),
            "Début stress": p["changement_regime"].get("date_debut_stress", "—"),
        })
    df = pd.DataFrame(rows)
    st.dataframe(
        df.style.apply(
            lambda row: [
                f"background-color: {'#450a0a' if 'ALERTE' in row['Statut'] else '#431407' if 'VIGILANCE' in row['Statut'] else '#0d2a0d'}; color: #c8e6c4;"
            ] * len(row),
            axis=1
        ),
        use_container_width=True,
        hide_index=True,
    )


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <div class="main-title">🫒 Agronomic Twin</div>
        <div class="main-subtitle">
            Détection précoce d'anomalies · Oliveraies tunisiennes · Hack The Harvest 2026
        </div>
    </div>
    """, unsafe_allow_html=True)

    sidebar = render_sidebar()

    # Session state
    if "result" not in st.session_state:
        st.session_state.result = None
    if "fleet" not in st.session_state:
        st.session_state.fleet = None

    # Main tabs
    tab_diag, tab_fleet = st.tabs(["🔬 Diagnostic parcelle", "🗺️ Vue flotte"])

    with tab_diag:
        # Parse demo
        if sidebar["demo"]:
            with st.spinner("Chargement démo jury..."):
                result = requests.get(f"{API_URL}/api/demo", timeout=30)
                if result.status_code == 200:
                    st.session_state.result = result.json()
                    st.success("✅ Démo chargée — oliveraie O_2026_307 (stress eau confirmé)")
                else:
                    st.error("Backend non joignable")

        # Parse manual run
        if sidebar["run"]:
            try:
                dates = [d.strip() for d in sidebar["dates_raw"].strip().splitlines() if d.strip()]
                ndvi = [float(v.strip()) for v in sidebar["ndvi_raw"].strip().splitlines() if v.strip()]
                lst = []
                if sidebar["lst_raw"].strip():
                    lst = [float(v.strip()) for v in sidebar["lst_raw"].strip().splitlines() if v.strip()]

                if len(dates) != len(ndvi):
                    st.error(f"Nombre de dates ({len(dates)}) ≠ nombre de NDVI ({len(ndvi)})")
                elif len(dates) < 3:
                    st.error("Minimum 3 acquisitions requises")
                else:
                    payload = {
                        "oliveraie": {
                            "id": sidebar["orchard_id"],
                            "systeme": sidebar["systeme"],
                            "centroide": {"lat": sidebar["lat"], "lon": sidebar["lon"]},
                        },
                        "dates": dates,
                        "ndvi": ndvi,
                        "lst": lst if lst else None,
                        "fetch_weather": sidebar["fetch_weather"],
                    }
                    with st.spinner("Analyse en cours — Prophet baseline · Isolation Forest · PELT..."):
                        result = call_api("/api/diagnostic-anomalie", payload)
                    if result:
                        st.session_state.result = result
            except ValueError as e:
                st.error(f"Erreur parsing: {e}")

        # Render result
        if st.session_state.result:
            render_result(st.session_state.result)
        else:
            st.markdown("""
            <div style="text-align: center; padding: 4rem 2rem; color: #2d4a2d;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🫒</div>
                <div style="font-family: 'Syne', sans-serif; font-size: 1.1rem; color: #4d7a4d;">
                    Entrez les données d'une oliveraie ou chargez la démo jury
                </div>
                <div style="font-size: 0.85rem; color: #2d4a2d; margin-top: 0.5rem;">
                    Backend API: """ + API_URL + """
                </div>
            </div>
            """, unsafe_allow_html=True)

    with tab_fleet:
        col_load, col_refresh = st.columns([3, 1])
        with col_load:
            if st.button("🔄 Charger la flotte démo (5 oliveraies)", use_container_width=True):
                with st.spinner("Analyse de la flotte en cours..."):
                    fleet = get_demo_fleet()
                if fleet:
                    st.session_state.fleet = fleet
        with col_refresh:
            if st.button("🗑️ Effacer", use_container_width=True):
                st.session_state.fleet = None

        if st.session_state.fleet:
            render_fleet_view(st.session_state.fleet)
        else:
            st.markdown("""
            <div style="text-align: center; padding: 3rem 2rem; color: #2d4a2d;">
                <div style="font-size: 2rem; margin-bottom: 1rem;">🗺️</div>
                <div style="font-family: 'Syne', sans-serif; font-size: 1rem; color: #4d7a4d;">
                    Chargez la flotte pour voir la carte des oliveraies
                </div>
            </div>
            """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
